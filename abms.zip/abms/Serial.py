import serial
import sys
import glob
import serial
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QDialog, QMainWindow
import subprocess
import os

class device(QDialog):
    def __init__(self):
        super(device, self).__init__()
        uic.loadUi("device.ui", self)
        self.show()
        self.sButton.clicked.connect(self.scan)
        self.cButton.clicked.connect(self.close)
        self.selectButton.clicked.connect(self.selButton)
        self.cBox.currentIndexChanged.connect(self.select)

    def scan(self):
        try:
            if sys.platform.startswith('win'):
                ports = ['COM%s' % (i + 1) for i in range(256)]
            elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
                # this excludes your current terminal "/dev/tty"
                ports = glob.glob('/dev/tty[A-Za-z]*')
            elif sys.platform.startswith('darwin'):
                ports = glob.glob('/dev/tty.*')
            else:
                raise EnvironmentError('Unsupported platform')

            result = []
            for port in ports:
                try:
                    s = serial.Serial(port)
                    s.close()
                    result.append(port)
                except (OSError, serial.SerialException):
                    pass

            self.cBox.addItems(result)


        except:
            self.statusLabel.setText("There is no attached device, Please insert your device")


    def closeEvent(self, e):
        self.close()

    def select(self):
        self.dev = self.cBox.currentText()


    def selButton(self):
        try:
            #uart = serial.Serial(self.dev)
            self.statusLabel.setText("Open {} success".format(self.dev))
            print("flex_abms launch")
            os.system("python deep_flex_abms.py -u {}".format(self.dev))
            self.close()

        except:
            self.statusLabel.setText("Unknown Error Occurred")

app = QApplication(sys.argv)
window = device()
app.exec_()

