import sys
import os
import time
import glob
import serial
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QDialog, QMainWindow, QGraphicsScene
from PyQt5.QtGui import QImage, QPixmap
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import queue
import threading
import acconeer.exptool as et
from PyQt5 import uic
from PyQt5.QtCore import QFile, QThread, QTimer
from PyQt5.QtWidgets import QApplication, QDialog, QWidget
import sys
import cv2
import qimage2ndarray
from PyQt5.QtGui import QPainter, QColor, QFont, QPen, QBrush, QPainterPath
from PyQt5.QtCore import Qt
from scipy.signal import butter, lfilter

main_data = queue.Queue()

class schedule(QThread):
    t = ""
    t_flag = 0
    t_flag1 = 0
    def __init__(self):
        super().__init__()

    def run(self):
        while True:
            try:
                self.t = time.asctime()
                time.sleep(10)
                self.t_flag = 1 
                self.t_flag1 = 1
            except:
                print("not good schedule")
                continue

class th(QThread):
    def __init__(self):
        super().__init__()

    def run(self):
        args = et.utils.ExampleArgumentParser().parse_args()

        # The client logs using the logging module with a logger named
        # acconeer.exptool.*. We call another helper function which sets up
        # the logging according to the verbosity level set in the arguments:
        # -q  or --quiet:   ERROR   (typically not used)
        # default:          WARNING
        # -v  or --verbose: INFO
        # -vv or --debug:   DEBUG
        et.utils.config_logging(args)

        # Pick client depending on whether socket, SPI, or UART is used
        if args.socket_addr:
            self.client = et.SocketClient(args.socket_addr)
        elif args.spi:
            self.client = et.SPIClient()
        else:
            port = args.serial_port or et.utils.autodetect_serial_port()
            self.client = et.UARTClient(port)

        # Create a configuration to run on the sensor. A good first choice
        # is the envelope service, so let's pick that one.
        config = et.EnvelopeServiceConfig()

        # In all examples, we let you set the sensor(s) via the command line
        config.sensor = args.sensors

        # Set the measurement range [meter]
        config.range_interval = [0.2, 0.8]

        # Set the target measurement rate [Hz]
        config.update_rate = 10

        # Other configuration options might be available. Check out the
        # example for the corresponding service/detector to see more.

        self.client.connect()

        # In most cases, explicitly calling connect is not necessary as
        # setup_session below will call connect if not already connected.

        # Set up the session with the config we created. If all goes well,
        # some information/metadata for the configured session is returned.
        session_info = self.client.setup_session(config)
        print("Session info:\n", session_info, "\n")

        # Now would be the time to set up plotting, signal processing, etc.

        # Start the session. This call will block until the sensor has
        # confirmed that it has started.
        self.client.start_session()

        while True:
            try:
                info, data1 = self.client.get_next()
                main_data.put(data1)
            except:
                print("data Gathering is not good")
                continue
            #print(main_data.qsize())

class draw(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.initUI()
        self.parent = parent
        
    def initUI(self):      
        self.setGeometry(300, 300, 400, 400)
        self.setWindowTitle('QPainter')
        #self.show()

    def paintEvent(self, event):
        qp = QPainter()
        qp.begin(self)
        self.drawText(event, qp)
        qp.end()

    def drawText(self, event, qp):
        qp.setPen(QPen(Qt.green, 3))
        qp.drawLine(30, 50, 30, 750)
        qp.setPen(QPen(Qt.green, 3))
        qp.drawLine(30, 750, 1400, 750)
        self.value = self.parent.data
        self.graph(event, qp, self.value)

    def graph(self, event, qp, value):
        qp.setPen(QPen(Qt.white, 3))
        try:
            for i in range(0, len(value) - 1):
                firstx = 30 + i
                firsty = np.abs(750 - int(value[i]/3.5))
                secondx = 30 + (i + 1)
                secondy = np.abs(750 - int(value[i+1]/3.5))
                qp.drawLine(firstx, firsty, secondx, secondy)
        except:
            print("Not good in draw")

class draw1(QWidget):
    breathFlag = 1
    def __init__(self, parent):
        super().__init__()
        self.initUI()
        self.parent = parent
        
    def initUI(self):      
        self.setGeometry(300, 300, 400, 400)
        self.setWindowTitle('QPainter')
        #self.show()

    def paintEvent(self, event):
        qp = QPainter()
        qp.begin(self)
        self.drawText(event, qp)
        qp.end()

    def drawText(self, event, qp):
        #data2 = main_data.get()
        qp.setPen(QColor(210, 210, 210))
        qp.setFont(QFont('Arial', 50))
        try:

            if self.parent.machine == 1:
                if (self.parent.the_being < 2 and self.parent.data_mean > 300) or self.parent.data_mean < 180:
                    qp.setFont(QFont('Arial', 30))
                    qp.drawText(event.rect(), Qt.AlignCenter, "There is None in Measuring.")
                elif self.parent.the_being >= 2 and self.parent.the_being < 250:
                    qp.drawText(event.rect(), Qt.AlignCenter, "Breath : {:.1f}".format(self.parent.breath))
                elif self.parent.the_being >= 350:
                    qp.setFont(QFont('Arial', 30))
                    qp.drawText(event.rect(), Qt.AlignCenter, "It seems to be moving.\n   Measuring again, please wait")
                else:
                    qp.drawText(event.rect(), Qt.AlignCenter, "Breath : {:.1f}".format(self.parent.breath))
            else:
                if (self.parent.the_being < 32 and self.parent.data_mean > 300) or self.parent.data_mean < 180:
                    qp.setFont(QFont('Arial', 30))
                    qp.drawText(event.rect(), Qt.AlignCenter, "There is None in Measuring.")
                elif self.parent.the_being >= 30 and self.parent.the_being < 250:
                    qp.drawText(event.rect(), Qt.AlignCenter, "Breath : {:.1f}".format(self.parent.breath))
                elif self.parent.the_being >= 350:
                    qp.setFont(QFont('Arial', 30))
                    qp.drawText(event.rect(), Qt.AlignCenter, "It seems to be moving.\n   Measuring again, please wait ")
                else:
                    qp.drawText(event.rect(), Qt.AlignCenter, "Breath : {:.1f}".format(self.parent.breath))
        except:
            print("Not good in Draw1")

class draw2(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.initUI()
        self.parent = parent
        
    def initUI(self):      
        self.setGeometry(300, 300, 400, 400)
        self.setWindowTitle('QPainter')
        #self.show()

    def paintEvent(self, event):
        qp = QPainter()
        qp.begin(self)
        self.drawText(event, qp)
        qp.end()

    def drawText(self, event, qp):
        #data2 = main_data.get()
        qp.setPen(QColor(180, 0, 200))
        qp.setFont(QFont('Arial', 35))
        if self.parent.machine == 1:
            qp.drawText(event.rect(), Qt.AlignCenter, 'Breath for machine')    
        else:
            qp.drawText(event.rect(), Qt.AlignCenter, 'Breath for Animal')

class draw3(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.initUI()
        self.parent = parent
        
    def initUI(self):      
        self.setGeometry(300, 300, 400, 400)
        self.setWindowTitle('QPainter')
        #self.show()

    def paintEvent(self, event):
        qp = QPainter()
        qp.begin(self)
        self.drawText(event, qp)
        qp.end()

    def drawText(self, event, qp):
        qp.setPen(QPen(Qt.green, 3))
        qp.drawLine(30, 50, 30, 750)
        qp.setPen(QPen(Qt.green, 3))
        qp.drawLine(30, 750, 1400, 750)
        self.value_fshit = abs(self.parent.fshift)
        self.graph(event, qp, self.value_fshit)

    def graph(self, event, qp, value):
        qp.setPen(QPen(Qt.white, 1))
        try:
            for i in range(0, len(value) - 1):
                firstx = 30 + i * 4
                tt = 750 - value[i]/16
                tt1 = 750 - value[i+1]/16
                if tt < 0 or tt1 < 0:
                    tt = 0
                    tt1 = 0

                firsty = tt
                secondx = 30 + (i + 1) * 4
                secondy = tt1
                qp.drawLine(firstx, firsty, secondx, secondy)
        except:
            print("not good in draw3")

class draw4(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.initUI()
        self.parent = parent
        
    def initUI(self):      
        self.setGeometry(300, 300, 400, 400)
        self.setWindowTitle('QPainter')
        #self.show()

    def paintEvent(self, event):
        qp = QPainter()
        qp.begin(self)
        self.drawText(event, qp)
        qp.end()

    def drawText(self, event, qp):
        qp.setPen(QPen(Qt.green, 3))
        qp.drawLine(30, 50, 30, 750)
        qp.setPen(QPen(Qt.green, 3))
        qp.drawLine(30, 750, 1400, 750)
        self.value_distance = abs(self.parent.distanceMax)
        self.graph(event, qp, self.value_distance)

    def graph(self, event, qp, value):
        qp.setPen(QPen(Qt.white, 3))
        try:
            for i in range(0, len(value) - 1):
                firstx = 30 + i*4
                firsty = np.abs(750 - int(value[i]/2))
                secondx = 30 + (i + 1)*4
                secondy = np.abs(750 - int(value[i+1]/2))
                qp.drawLine(firstx, firsty, secondx, secondy)
        except:
            print("not good in draw4")

class draw5(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.initUI()
        self.parent = parent
        
    def initUI(self):      
        self.setGeometry(300, 300, 400, 400)
        self.setWindowTitle('QPainter')
        #self.show()

    def paintEvent(self, event):
        qp = QPainter()
        qp.begin(self)
        self.drawText(event, qp)
        qp.end()

    def drawText(self, event, qp):
        qp.setPen(QPen(Qt.green, 3))
        qp.drawLine(30, 50, 30, 750)
        qp.setPen(QPen(Qt.green, 3))
        qp.drawLine(30, 750, 1400, 750)
        self.value_lowpassed = abs(self.parent.lowpassed)
        self.graph(event, qp, self.value_lowpassed)

    def graph(self, event, qp, value):
        qp.setPen(QPen(Qt.white, 3))
        for i in range(0, len(value) - 1):
            firstx = 30 + i*4
            firsty = 750 - int(value[i]/2)
            secondx = 30 + (i + 1)*4
            secondy = 750 - int(value[i+1]/2)
            qp.drawLine(firstx, firsty, secondx, secondy)


class Acconeer(QMainWindow):
    i = 0
    total = 300
    enable = 0
    distanceMax = np.zeros(total)
    data_max = np.zeros(total)
    the_being = 0
    lowpassed = np.zeros(total)

    cnt = 0
    cnt1 = 0
    cnt2 = 0
    data = np.zeros(1240)
    fshift = np.zeros(300)
    data_mean = 0
    tim = total / 10
    res = (10 / total) * 60
    x = np.arange(0, 30, 1)
    breath = 0
    machine = 0
    breath1 = 0
    mcnt = 0

    def __init__(self):
        super(Acconeer, self).__init__()
        uic.loadUi("acconeer.ui", self)


        self.pWidget = draw(self)
        self.pWidget1 = draw1(self)
        self.pWidget2 = draw2(self)
        self.pWidget3 = draw3(self)
        self.pWidget4 = draw4(self)
        self.pWidget5 = draw5(self)
        self.rawView.addWidget(self.pWidget)
        self.nLayout.addWidget(self.pWidget1)
        self.sLayout.addWidget(self.pWidget2)
        self.FFTView.addWidget(self.pWidget3)
        self.maxDistanceView.addWidget(self.pWidget4)
        self.LPFView.addWidget(self.pWidget5)
        
        
        self.x = th()        
        self.x.start()

        

        timer = QTimer(self)
        timer.setInterval(1)
        timer.timeout.connect(self.timerService)
        timer.start()

        timer1 = QTimer(self)
        timer1.setInterval(1)
        timer1.timeout.connect(self.timerProcess)
        timer1.start()

        self.VideoSignal = cv2.VideoCapture(1) 

        timer2 = QTimer(self)
        timer2.setInterval(1)
        timer2.timeout.connect(self.vision)
        timer2.start()

        self.s = schedule()
        self.s.start()

        self.show()

        self.sWidget.setCurrentIndex(0)
        self.aOpen.triggered.connect(self.open)
        self.aClose.triggered.connect(self.closeDevice)
        self.aStart.triggered.connect(self.initial)
        self.aCloseProgram.triggered.connect(self.close1)
        self.aRawDataView.triggered.connect(self.raw)
        self.aMaxDistanceView.triggered.connect(self.max)
        self.aLPFView.triggered.connect(self.filter)
        self.aFFTView.triggered.connect(self.fft)
        self.mButton.clicked.connect(self.machine)

        self.fp = open("temp.csv", "w+")

    def vision(self):
        ret, frame = self.VideoSignal.read()
                
        frame = cv2.resize(frame, (320, 240))

        if self.s.t_flag1 == 1:
            self.s.t_flag1 = 0
            tstring = self.s.t
            tstring = tstring.replace(" ", "_")
            tstring = tstring.replace(":", "_")
            cv2.imwrite("image\{}_breath_{}.png".format(tstring, int(self.breath)), frame)
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        #h, w, c = frame.shape
        qImage = QImage(frame.data, frame.shape[1], frame.shape[0], QImage.Format_RGB888)
        #qImage = QImage(frame.data, w, h, w*c, QImage.Format_RGB888)
        qPixmap = QPixmap.fromImage(qImage)
        scene = QGraphicsScene()
        scene.addPixmap(qPixmap)
        self.visionLabel_2.setScene(scene)

    def machine(self):
        self.mcnt = self.mcnt + 1
        if self.mcnt % 2 == 1:
            self.machine = 1
        else:
            self.machine = 0

    def butter_lowpass(self, cutoff, fs, order=9):
        nyq = 0.5 * fs
        normal_cutoff = cutoff / nyq
        b, a = butter(order, normal_cutoff, btype='low', analog=False)
        return b, a

    def butter_lowpass_filter(self, data, cutoff, fs, order=9):
        b, a = self.butter_lowpass(cutoff, fs, order=order)
        y = lfilter(b, a, data)
        return y
        
    def timerProcess(self):
        self.data = main_data.get()
        if self.s.t_flag == 1:
            self.s.t_flag = 0
            for i in range(1240):
                self.fp.write("{},".format(self.data[i]))
            self.fp.write("{}".format(self.breath))
            self.fp.write("\n" + self.s.t)

       # print(len(self.data))
        self.distanceMax[self.cnt] = np.argmax(self.data)
        self.data_mean = np.max(self.data)
        self.data_max = np.max(self.distanceMax)
        self.data_min = np.min(self.distanceMax)
        self.the_being = self.data_max - self.data_min
        self.lowpassed = self.butter_lowpass_filter(self.distanceMax, 0.65, 10, order=9)
        self.freq = np.fft.fft(self.lowpassed[50:])
        self.fshift = np.fft.fftshift(self.freq)
        self.cnt = self.cnt + 1


        if self.cnt % 10 == 0 and self.enable == 1:
            #print("The being is {}".format(the_being))
            self.breath1 = np.argmax(abs(self.fshift[0:int(len(self.fshift)/2) - 3]))
            #print("index {}".format(breath))
            #self.breath = -2 * self.breath1 + 254
            self.breath = np.abs(-2.22222 * self.breath1 + 280)
            #print("breath : {}".format(breath))
            
        if self.cnt == 300:
            self.enable = 1
            self.cnt = 0

    def close1(self):
        self.r.VideoSignal.release()
        self.x.client.disconect()
        self.x.client.stop_session()
        
        
        self.close()

    def closeEvent(self, e):
        self.r.VideoSignal.release()
        self.x.client.disconnect()
        self.x.client.stop_session()
        
        self.close()

    def timerService(self):
        self.pWidget.update()
        self.pWidget2.update()
        self.pWidget1.update()
        self.pWidget3.update()
        self.pWidget4.update()
        self.pWidget5.update()

    def open(self):
        pass
        #self.dev = device()

    def closeDevice(self):
        #self.dev.uart.close()
        self.x.client.disconnect()
        self.x.client.stop_session()
        

    def initial(self):
        self.sWidget.setCurrentIndex(0)

    def raw(self):
        self.sWidget.setCurrentIndex(1)

    def max(self):
        self.sWidget.setCurrentIndex(2)

    def filter(self):
        self.sWidget.setCurrentIndex(3)

    def fft(self):
        self.sWidget.setCurrentIndex(4)
            
app = QApplication(sys.argv)
windows = Acconeer()
app.exec_()