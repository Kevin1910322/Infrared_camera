import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.utils import to_categorical
from tensorflow.keras import Sequential
from tensorflow.keras import layers, models

data = pd.read_csv("data.csv")
data_no = np.array(data)
nTrain = 30

x_train = data_no[:, 1:-1].astype(float)
y_train = data_no[:, 1240].astype(float)

for i in range(0, len(x_train)-1, 1):
    plt.plot(x_train[i, :])
    plt.ylabel(y_train[i])
    plt.pause(0.1)
    plt.cla()
    time.sleep(0.1)

print(y_train)

#y_train = np_utils.to_categorical(y_train, 3)
#y_train = to_categorical(y_train)
#x_train = np.expand_dims(x_train, -1)

model = Sequential()
model.add(layers.Conv1D(filters=32, kernel_size=3, input_shape=(1239, 1), activation='relu'))
model.add(layers.Conv1D(filters=32, kernel_size=3, activation='relu'))
model.add(layers.MaxPooling1D(pool_size=3, strides=2))
model.add(layers.Conv1D(filters=16, kernel_size=3, activation='relu'))
model.add(layers.MaxPooling1D(pool_size=3, strides=2))
#model.add(layers.LSTM(32))
model.add(layers.Flatten())
model.add(layers.Dense(1024, activation='relu'))
model.add(layers.Dense(2054, activation='relu'))
model.add(layers.Dense(3, activation='softmax'))

model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
hist = model.fit(x_train, y_train, epochs=80)

#loss, acc = model.evaluate(x_test, y_test, verbose=2)

model.save('deep_flex_abms.h5')
#model = model.load_model('model.h5')


