import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras import layers, models

model = model.load_model('model.h5')
model.predict()


